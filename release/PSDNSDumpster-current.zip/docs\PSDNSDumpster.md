﻿---
Module Name: PSDNSDumpster
Module Guid: cb0a589a-fc8f-44fd-90dc-c9be3827a2f3
Download Help Link: https://github.com/justin-p/PSDNSDumpster/release/PSDNSDumpster/docs/PSDNSDumpster.md
Help Version: 0.0.1
Locale: en-US
---

# PSDNSDumpster Module
## Description
Unofficial DNSDumpster API

## PSDNSDumpster Cmdlets
### [Get-DNSD](Get-DNSD.md)
TBD


