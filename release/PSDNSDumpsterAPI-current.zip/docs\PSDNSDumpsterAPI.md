﻿---
Module Name: PSDNSDumpsterAPI
Module Guid: cb0a589a-fc8f-44fd-90dc-c9be3827a2f3
Download Help Link: https://github.com/justin-p/PSDNSDumpsterAPI/release/PSDNSDumpsterAPI/docs/PSDNSDumpsterAPI.md
Help Version: 0.0.2
Locale: en-US
---

# PSDNSDumpsterAPI Module
## Description
(Unofficial) PowerShell API for dnsdumpster

## PSDNSDumpsterAPI Cmdlets
### [Invoke-PSDNSDumpsterAPI](Invoke-PSDNSDumpsterAPI.md)
Send a webrequest to DNSDumpster, parse output and return it as a PSObject.


